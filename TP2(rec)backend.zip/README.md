# ApiTurnos (NET 8) - Trabajo Práctico N°2 (Recuperación)

Proyecto ejemplo listo para Visual Studio / dotnet CLI.

## Requisitos
- .NET 8 SDK instalado.

## Ejecutar
Desde la carpeta que contiene ApiTurnos.csproj:
```bash
dotnet restore
dotnet run
```

La API utiliza InMemory EF Core. Se expone Swagger en `http://localhost:5000/swagger` (o el puerto que muestre dotnet).

Rutas principales:
- `GET  /api/paciente/{idPaciente}/turnoMedico`
- `POST /api/paciente/{idPaciente}/turnoMedico`
- `PUT  /api/paciente/{idPaciente}/turnoMedico/{idTurno}`
- `DELETE /api/paciente/{idPaciente}/turnoMedico/{idTurno}`

