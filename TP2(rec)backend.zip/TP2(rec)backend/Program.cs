using ApiTurnos.Data;
using ApiTurnos.Mapping;
using ApiTurnos.Repositorio;
using ApiTurnos.Services;
using AutoMapper;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<AppDbContext>(opt =>
    opt.UseInMemoryDatabase("TurnosDb"));

IMapper mapper = MappingConfig.RegisterMaps().CreateMapper();
builder.Services.AddSingleton(mapper);
builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());

builder.Services.AddScoped<ITurnoMedicoRepositorio, TurnoMedicoRepositorio>();
builder.Services.AddScoped<TurnoMedicoService>();

builder.Services.AddScoped<IPacienteRepositorio, PacienteRepositorio>();
builder.Services.AddScoped<PacienteService>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

app.MapControllers();

using (var scope = app.Services.CreateScope())
{
    var ctx = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    ctx.Pacientes.Add(new ApiTurnos.Models.Paciente { Nombre = "Juan", Apellido = "Perez" });
    ctx.Pacientes.Add(new ApiTurnos.Models.Paciente { Nombre = "Ana", Apellido = "Gomez" });
    ctx.SaveChanges();
}

app.Run();