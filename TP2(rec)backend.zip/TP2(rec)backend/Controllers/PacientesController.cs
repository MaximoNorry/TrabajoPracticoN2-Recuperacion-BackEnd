using ApiTurnos.Dtos;
using ApiTurnos.Services;
using Microsoft.AspNetCore.Mvc;

namespace ApiTurnos.Controllers
{
    [ApiController]
    [Route("api/pacientes")] 
    public class PacientesController : ControllerBase
    {
        private readonly PacienteService _service;

        public PacientesController(PacienteService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetPacientes()
        {
            var pacientes = await _service.GetPacientesAsync();
            return Ok(pacientes);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetPaciente(int id)
        {
            var paciente = await _service.GetPacientePorIdAsync(id);
            if (paciente == null) return NotFound();
            return Ok(paciente);
        }

        [HttpPost]
        public async Task<IActionResult> CrearPaciente([FromBody] PacienteCreateDto dto)
        {
            if (dto == null) return BadRequest();
            var creado = await _service.CrearPacienteAsync(dto);
            return CreatedAtAction(nameof(GetPaciente), new { id = creado.Id }, creado);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> ActualizarPaciente(int id, [FromBody] PacienteDto dto)
        {
            if (id != dto.Id) return BadRequest("El ID de la URL no coincide con el ID del cuerpo");
            
            var actualizado = await _service.ActualizarPacienteAsync(id, dto);
            if (actualizado == null) return NotFound();
            return Ok(actualizado);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> EliminarPaciente(int id)
        {
            var eliminado = await _service.EliminarPacienteAsync(id);
            if (!eliminado) return NotFound("No se pudo eliminar el paciente (quizás tiene turnos asignados o no existe).");
            return NoContent(); 
        }
    }
}