using ApiTurnos.Data;
using ApiTurnos.Models;
using Microsoft.EntityFrameworkCore;

namespace ApiTurnos.Repositorio
{
    public class PacienteRepositorio : IPacienteRepositorio
    {
        private readonly AppDbContext _context;

        public PacienteRepositorio(AppDbContext context)
        {
            _context = context;
        }

        public async Task<Paciente> CrearPacienteAsync(Paciente paciente)
        {
            _context.Pacientes.Add(paciente);
            await _context.SaveChangesAsync();
            return paciente;
        }

        public async Task<Paciente?> ActualizarPacienteAsync(Paciente paciente)
        {
            var existente = await _context.Pacientes.FindAsync(paciente.Id);
            if (existente == null) return null;

            existente.Nombre = paciente.Nombre;
            existente.Apellido = paciente.Apellido;

            await _context.SaveChangesAsync();
            return existente;
        }

        public async Task<bool> EliminarPacienteAsync(int id)
        {
            var paciente = await _context.Pacientes.FindAsync(id);
            if (paciente == null) return false;

            bool tieneTurnos = await _context.TurnosMedicos.AnyAsync(t => t.PacienteId == id);
            if (tieneTurnos)
            {
                return false; 
            }

            _context.Pacientes.Remove(paciente);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<Paciente?> GetPacientePorIdAsync(int id)
        {
            return await _context.Pacientes.FindAsync(id);
        }

        public async Task<IEnumerable<Paciente>> GetPacientesAsync()
        {
            return await _context.Pacientes.ToListAsync();
        }

        public async Task<bool> ExistePacienteAsync(int id)
        {
            return await _context.Pacientes.AnyAsync(p => p.Id == id);
        }
    }
}