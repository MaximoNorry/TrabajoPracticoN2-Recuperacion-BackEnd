using ApiTurnos.Dtos;
using ApiTurnos.Services;
using Microsoft.AspNetCore.Mvc;

namespace ApiTurnos.Controllers
{
    [ApiController]
    [Route("api/paciente/{idPaciente}/turnoMedico")]
    public class PacienteController : ControllerBase 
    {
        private readonly TurnoMedicoService _service;

        public PacienteController(TurnoMedicoService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetTurnos(int idPaciente)
        {
            var turnos = await _service.GetTurnosPorPacienteAsync(idPaciente);
            return Ok(turnos);
        }

        [HttpPost]
        public async Task<IActionResult> CrearTurno(int idPaciente, [FromBody] TurnoMedicoDto dto)
        {
            dto.PacienteId = idPaciente;
            var creado = await _service.CrearTurnoAsync(dto);

            if (creado == null)
            {
                return NotFound(new { message = $"El paciente con ID {idPaciente} no existe." });
            }

            return CreatedAtAction(nameof(GetTurnos), new { idPaciente }, creado);
        }

        [HttpPut("{idTurno}")]
        public async Task<IActionResult> ActualizarTurno(int idPaciente, int idTurno, [FromBody] TurnoMedicoDto dto)
        {
            dto.Id = idTurno;
            dto.PacienteId = idPaciente;
            var actualizado = await _service.ActualizarTurnoAsync(dto);
            if (actualizado == null) return NotFound("No se encontró el turno o el paciente asociado.");
            return Ok(actualizado);
        }

        [HttpDelete("{idTurno}")]
        public async Task<IActionResult> EliminarTurno(int idTurno)
        {
            var eliminado = await _service.EliminarTurnoAsync(idTurno);
            if (!eliminado) return NotFound();
            return NoContent();
        }
    }
}