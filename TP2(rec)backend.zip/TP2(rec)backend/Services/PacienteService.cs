using ApiTurnos.Dtos;
using ApiTurnos.Models;
using ApiTurnos.Repositorio;
using AutoMapper;

namespace ApiTurnos.Services
{
    public class PacienteService
    {
        private readonly IPacienteRepositorio _repositorio;
        private readonly IMapper _mapper;

        public PacienteService(IPacienteRepositorio repositorio, IMapper mapper)
        {
            _repositorio = repositorio;
            _mapper = mapper;
        }

        public async Task<IEnumerable<PacienteDto>> GetPacientesAsync()
        {
            var pacientes = await _repositorio.GetPacientesAsync();
            return _mapper.Map<IEnumerable<PacienteDto>>(pacientes);
        }

        public async Task<PacienteDto?> GetPacientePorIdAsync(int id)
        {
            var paciente = await _repositorio.GetPacientePorIdAsync(id);
            return _mapper.Map<PacienteDto>(paciente);
        }

        public async Task<PacienteDto> CrearPacienteAsync(PacienteCreateDto dto)
        {
            var paciente = _mapper.Map<Paciente>(dto);
            var creado = await _repositorio.CrearPacienteAsync(paciente);
            return _mapper.Map<PacienteDto>(creado);
        }

        public async Task<PacienteDto?> ActualizarPacienteAsync(int id, PacienteDto dto)
        {
            if (id != dto.Id) return null; 

            var paciente = _mapper.Map<Paciente>(dto);
            var actualizado = await _repositorio.ActualizarPacienteAsync(paciente);
            return actualizado == null ? null : _mapper.Map<PacienteDto>(actualizado);
        }

        public async Task<bool> EliminarPacienteAsync(int id)
        {
            return await _repositorio.EliminarPacienteAsync(id);
        }
    }
}