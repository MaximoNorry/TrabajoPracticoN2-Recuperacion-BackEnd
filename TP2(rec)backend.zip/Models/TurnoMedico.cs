namespace ApiTurnos.Models
{
    public class TurnoMedico
    {
        public int Id { get; set; }
        public string Especialidad { get; set; } = string.Empty;
        public DateTime Fecha { get; set; }

        public int PacienteId { get; set; }
        public Paciente? Paciente { get; set; }
    }
}
