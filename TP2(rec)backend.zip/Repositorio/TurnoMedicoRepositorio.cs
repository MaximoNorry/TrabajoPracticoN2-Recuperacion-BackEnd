using ApiTurnos.Data;
using ApiTurnos.Models;
using Microsoft.EntityFrameworkCore;

namespace ApiTurnos.Repositorio
{
    public class TurnoMedicoRepositorio : ITurnoMedicoRepositorio
    {
        private readonly AppDbContext _context;

        public TurnoMedicoRepositorio(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<TurnoMedico>> GetTurnosPorPacienteAsync(int pacienteId)
        {
            return await _context.TurnosMedicos
                .Where(t => t.PacienteId == pacienteId)
                .ToListAsync();
        }

        public async Task<TurnoMedico?> GetTurnoPorIdAsync(int id)
        {
            return await _context.TurnosMedicos.FindAsync(id);
        }

        public async Task<TurnoMedico> CrearTurnoAsync(TurnoMedico turno)
        {
            _context.TurnosMedicos.Add(turno);
            await _context.SaveChangesAsync();
            return turno;
        }

        public async Task<TurnoMedico?> ActualizarTurnoAsync(TurnoMedico turno)
        {
            var existente = await _context.TurnosMedicos.FindAsync(turno.Id);
            if (existente == null) return null;

            existente.Especialidad = turno.Especialidad;
            existente.Fecha = turno.Fecha;
            existente.PacienteId = turno.PacienteId;

            await _context.SaveChangesAsync();
            return existente;
        }

        public async Task<bool> EliminarTurnoAsync(int id)
        {
            var turno = await _context.TurnosMedicos.FindAsync(id);
            if (turno == null) return false;

            _context.TurnosMedicos.Remove(turno);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
