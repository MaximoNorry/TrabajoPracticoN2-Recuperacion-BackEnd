using ApiTurnos.Models;

namespace ApiTurnos.Repositorio
{
    public interface ITurnoMedicoRepositorio
    {
        Task<IEnumerable<TurnoMedico>> GetTurnosPorPacienteAsync(int pacienteId);
        Task<TurnoMedico?> GetTurnoPorIdAsync(int id);
        Task<TurnoMedico> CrearTurnoAsync(TurnoMedico turno);
        Task<TurnoMedico?> ActualizarTurnoAsync(TurnoMedico turno);
        Task<bool> EliminarTurnoAsync(int id);
    }
}
