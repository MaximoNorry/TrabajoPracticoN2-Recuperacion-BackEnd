using AutoMapper;
using ApiTurnos.Models;
using ApiTurnos.Dtos;

namespace ApiTurnos.Mapping
{
    public class MappingConfig
    {
        public static MapperConfiguration RegisterMaps()
        {
            var mappingConfig = new MapperConfiguration(config =>
            {
                config.CreateMap<TurnoMedico, TurnoMedicoDto>().ReverseMap();
                config.CreateMap<Paciente, PacienteDto>().ReverseMap();
                config.CreateMap<Paciente, PacienteCreateDto>().ReverseMap();
            });
            return mappingConfig;
        }
    }
}