namespace ApiTurnos.Dtos
{
    public class TurnoMedicoDto
    {
        public int Id { get; set; }
        public string Especialidad { get; set; } = string.Empty;
        public DateTime Fecha { get; set; }
        public int PacienteId { get; set; }
    }
}
