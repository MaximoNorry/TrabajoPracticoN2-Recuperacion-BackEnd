using Microsoft.EntityFrameworkCore;
using ApiTurnos.Models;

namespace ApiTurnos.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Paciente> Pacientes { get; set; } = null!;
        public DbSet<TurnoMedico> TurnosMedicos { get; set; } = null!;
    }
}
