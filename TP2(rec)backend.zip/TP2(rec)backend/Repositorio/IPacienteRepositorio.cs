using ApiTurnos.Models;

namespace ApiTurnos.Repositorio
{
    public interface IPacienteRepositorio
    {
        Task<IEnumerable<Paciente>> GetPacientesAsync();
        Task<Paciente?> GetPacientePorIdAsync(int id);
        Task<Paciente> CrearPacienteAsync(Paciente paciente);
        Task<Paciente?> ActualizarPacienteAsync(Paciente paciente);
        Task<bool> EliminarPacienteAsync(int id);
        Task<bool> ExistePacienteAsync(int id);
    }
}