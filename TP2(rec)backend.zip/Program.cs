using ApiTurnos.Data;
using ApiTurnos.Mapping;
using ApiTurnos.Repositorio;
using ApiTurnos.Services;
using AutoMapper;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add DbContext - InMemory
builder.Services.AddDbContext<AppDbContext>(opt =>
    opt.UseInMemoryDatabase("TurnosDb"));

// AutoMapper
IMapper mapper = MappingConfig.RegisterMaps().CreateMapper();
builder.Services.AddSingleton(mapper);
builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());

// Repositorio y Servicio
builder.Services.AddScoped<ITurnoMedicoRepositorio, TurnoMedicoRepositorio>();
builder.Services.AddScoped<TurnoMedicoService>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

app.MapControllers();

// Seed simple data
using (var scope = app.Services.CreateScope())
{
    var ctx = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    ctx.Pacientes.Add(new ApiTurnos.Models.Paciente { Nombre = "Juan", Apellido = "Perez" });
    ctx.Pacientes.Add(new ApiTurnos.Models.Paciente { Nombre = "Ana", Apellido = "Gomez" });
    ctx.SaveChanges();
}

app.Run();
